# FX Calculator

###Objective
The objective is to write a console-based currency converter application.A user should be allowed  
to convert an amount in a specific currency to the equivalent amount in another currency. The user is to
 enter an amount in any of the known currencies, and the application will provide the equivalent amount in another
currency.

###How to use the application
The main class to run the application is ForexCalculatorDemo.java. It provides a 
console and the user should enter input in the format like: XXX 100.00 in YYY
when the intent is to convert 100.00 from currency XXX to currency YYY.
To end the program enter text QUIT or END