package com.assignment;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

public class ForexCalculator {
	private static final String CURRENCY_PAIR_RATES_FILE_PATH = ".\\src\\main\\resources\\java\\util\\CurrencyPairRates.txt";
	private Map<String, BigDecimal> currencyPairRates;
	private Map<String, Map<String, String>> crossRateDirections;


	public String processUserInput(String consoleInputString) throws ForexCalculationException{
		//ResourceBundle rb = ResourceBundle.getBundle(arg0)
		
		ValidateInput.checkUserInput(consoleInputString);
		String[] consoleInput = consoleInputString.trim().split(" ");
		BigDecimal sourceAmount = new BigDecimal(consoleInput[1]);
		BigDecimal calculatedOveralExchangeRate = getExchangeRate(consoleInput[0], consoleInput[3]);
		BigDecimal convertedAmount = calculatedOveralExchangeRate.multiply(sourceAmount);
		convertedAmount = convertedAmount.setScale(Currency.getInstance(consoleInput[3]).getDefaultFractionDigits(), BigDecimal.ROUND_HALF_EVEN);
		String result = consoleInput[0] + " " + sourceAmount + " = " + consoleInput[3] + " " + convertedAmount;
		System.out.println(result);
		return result;
	}

	BigDecimal getExchangeRate(String fromCurrency, String toCurrency) {
		if (fromCurrency.equalsIgnoreCase(toCurrency))
			return new BigDecimal(1);
		if (currencyPairRates.containsKey((fromCurrency + toCurrency)))
			return currencyPairRates.get(fromCurrency + toCurrency);
		if (currencyPairRates.containsKey((toCurrency + fromCurrency)))
			return new BigDecimal(1).divide(currencyPairRates.get(toCurrency + fromCurrency), 6, BigDecimal.ROUND_FLOOR);
		else
			return getCrossRate(fromCurrency, toCurrency);
	}

	BigDecimal getCrossRate(String fromCurrency, String toCurrency) {
		if (crossRateDirections.containsKey(fromCurrency)) {
			String crossCurrency = crossRateDirections.get(fromCurrency).get(toCurrency);
			return getDirectOrInverseExchangeRate(fromCurrency, crossCurrency)
					.multiply(getDirectOrInverseExchangeRate(crossCurrency, toCurrency));
		} else {
			return getDirectOrInverseExchangeRate(fromCurrency, "USD").multiply(getExchangeRate("USD", toCurrency));
		}
	}
	
	BigDecimal getDirectOrInverseExchangeRate(String fromCurrency, String toCurrency) {
		if (currencyPairRates.containsKey((fromCurrency + toCurrency)))
			return currencyPairRates.get(fromCurrency + toCurrency);
		else
			return new BigDecimal(1).divide(currencyPairRates.get(toCurrency + fromCurrency), 6, BigDecimal.ROUND_FLOOR);
	}

	public ForexCalculator() throws ForexCalculationException {
		super();
		currencyPairRates = new HashMap<String, BigDecimal>();	
		try {
			Stream<String> currencyRatesLines = Files.lines(Paths.get(CURRENCY_PAIR_RATES_FILE_PATH));
			currencyRatesLines.forEach(x->currencyPairRates.put(x.substring(0, 6), new BigDecimal(x.substring(7))));
		} catch (Exception e) {
			throw new ForexCalculationException("Error encountered during reading if Currency Rates file. ");
		}
	
		
		crossRateDirections = new HashMap<>();
		// CZK
		Map<String, String> czk = new HashMap<>();
		czk.put("NOK", "EUR");
		czk.put("DKK", "EUR");
		czk.put("USD", "EUR");
		crossRateDirections.put("CZK", czk);

		// DKK
		Map<String, String> dkk = new HashMap<>();
		dkk.put("CZK", "EUR");
		dkk.put("NOK", "EUR");
		dkk.put("USD", "EUR");
		crossRateDirections.put("DKK", dkk);

		// NOK
		Map<String, String> nok = new HashMap<>();
		nok.put("CZK", "EUR");
		nok.put("DKK", "EUR");
		nok.put("USD", "EUR");
		crossRateDirections.put("NOK", nok);

		// USD
		Map<String, String> usd = new HashMap<>();
		usd.put("CZK", "EUR");
		usd.put("DKK", "EUR");
		usd.put("NOK", "EUR");
		crossRateDirections.put("USD", usd);
	}
}