package com.assignment;

public class ForexCalculationException extends Exception{

	private static final long serialVersionUID = 1L;
	public ForexCalculationException(String description) {
		super(description);
	}

}
