package com.assignment;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;



public class ValidateInput {
	
	public static List<String> currencyName = Arrays.asList("AUD", "CAD", "CNY", "CZK", "DKK", "EUR", "GBP" ,"JPY", "NOK", "NZD", "USD");
	
	public static boolean isCurrencyValid(String currency) {
	    if (currency == null) {
	        return false;
	    }
	    
		if(currency.length()!=3)
			return false;
		
		if(!currencyName.contains(currency))
			return false;
		
		return true;
	}
	
	public static boolean checkTheInTextEntry( String text) {
	    if (text.equalsIgnoreCase("IN")) {
	        return true;
	    }
			return false;
	}
	public static boolean isAmountValid(String amount) {
	    if (amount == null) {
	        return false;
	    }
		  
		try {
				new BigDecimal(amount);
			} catch (NumberFormatException e) {
				System.out.println("Invalid amount given. Check amount.");
				return false;
			}
       return true;
	}

	public static void checkUserInput(String userinput) throws ForexCalculationException{
		String[] input = userinput.trim().split(" ");
		if(input.length!=4) { 
			throw new ForexCalculationException("Invalid input. Check your entry.");
		}
		
		if(!isAmountValid(input[1])) {
			throw new ForexCalculationException("Invalid input. Check your entry.");  
		}
		
		if(!checkTheInTextEntry(input[2])){
			throw new ForexCalculationException("Invalid input. Check your entry, especially the IN text entry.");	
		}
		
		if(!isCurrencyValid(input[0])) {
			throw new ForexCalculationException("Unable to find rate for " + input[0] + "/" + input[3]);
		}
		
		if(!isCurrencyValid(input[3])) {
			throw new ForexCalculationException("Unable to find rate for " + input[0] + "/" + input[3]);
		}
		
	}
}
