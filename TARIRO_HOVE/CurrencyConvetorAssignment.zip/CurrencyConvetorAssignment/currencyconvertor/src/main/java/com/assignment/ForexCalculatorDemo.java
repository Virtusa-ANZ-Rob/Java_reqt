package com.assignment;

import java.util.Scanner;

public class ForexCalculatorDemo {

	public static void main(String[] args) {
		System.setProperty("java.util.currency.data", "src\\main\\resources\\java\\util\\currency.data");
		Scanner in = new Scanner(System.in);
		System.out.println("This application allows a user to convert an amount in a specific currency to the");
		System.out.println("equivalent amount in another currency: ");
		System.out.println("Please enter input in the format like: <ccy1> <amount> in <ccy2>");
		System.out.println("Enter text QUIT or END to end the application");
		
		String userinput = "";	
		while (true) {
		userinput = in.nextLine();
		if (userinput.equalsIgnoreCase("QUIT")||userinput.equalsIgnoreCase("END"))
			break;
		System.out.println("User input: %>" + userinput);
		try {
			ForexCalculator fc = new ForexCalculator();
			fc.processUserInput(userinput);
		} catch (ForexCalculationException e) {
			System.out.println(e.getMessage());
		}
	  }
		System.out.println("Application Closed!");
		in.close();
	}
}

