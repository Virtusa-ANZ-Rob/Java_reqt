package com.assignment;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ValidateInputTest {
	@Rule
	public final ExpectedException exception = ExpectedException.none();
	
	public static List<String> currencyNames = Arrays.asList("AUD", "CAD", "CNY", "CZK", "DKK", "EUR", "GBP", "JPY",
			"NOK", "NZD", "USD");

	

	@Test
	public void testUserInputShouldBeCheckedForValidInput() throws ForexCalculationException {
		ValidateInput.checkUserInput(" AUD 100.00 in USD");
		ValidateInput.checkUserInput(" AUD 100.00 in USD ");
		ValidateInput.checkUserInput("AUD 100.00 in USD ");
	}

	@Test
	public void testCurrencyValues() {
		for (String currency : currencyNames)
			assertTrue(ValidateInput.isCurrencyValid(currency));
	}

	@Test
	public void testInValues() {
		assertTrue(ValidateInput.checkTheInTextEntry("in"));
		assertTrue(ValidateInput.checkTheInTextEntry("IN"));
		assertTrue(ValidateInput.checkTheInTextEntry("In"));
		assertFalse(ValidateInput.checkTheInTextEntry("XU"));
	}
	
	@Test
	public void testUserInputShouldBeCheckedForValidInput_wrong_to_currency_value() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 100.00 in USDD");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_invalid_amount_given() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 10R0.00 in USD");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_too_many_spaces() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 100.00  in USD");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_too_many_fields() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 100.00 in US D");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_too_many_fields2() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 100.00 in USD and ");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_invalid_from_value() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUX 100.00 in USD");
        }

	@Test
	public void testUserInputShouldBeCheckedForValidInput_invalid_to_cur_val() throws ForexCalculationException {
		exception.expect(ForexCalculationException.class);
		ValidateInput.checkUserInput("AUD 100.00 in USX");
        }
	
	

}
