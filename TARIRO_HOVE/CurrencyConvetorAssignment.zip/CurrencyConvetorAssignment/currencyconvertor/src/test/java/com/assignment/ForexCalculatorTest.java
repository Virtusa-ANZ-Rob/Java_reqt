package com.assignment;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;

public class ForexCalculatorTest {
	ForexCalculator fc;

	@Before
	public void setup() throws ForexCalculationException  {
		fc = new ForexCalculator();
	}

	@Test
	public void testConverstion() throws ForexCalculationException {
		assertEquals("AUD 100.00 = USD 83.71", fc.processUserInput("AUD 100.00 in USD"));
		assertEquals("AUD 100.00 = AUD 100.00", fc.processUserInput("AUD 100.00 in AUD"));
		assertEquals("AUD 100.00 = DKK 505.76", fc.processUserInput("AUD 100.00 in DKK"));
		assertEquals("JPY 100 = USD 0.83", fc.processUserInput("JPY 100 in USD"));
	}

	@Test
	public void testDirectRates() {
		assertEquals(new BigDecimal("0.8371"), fc.getExchangeRate("AUD", "USD"));
		assertEquals(new BigDecimal("0.8371"), fc.getExchangeRate("AUD", "USD"));
		assertEquals(new BigDecimal("0.8711"), fc.getExchangeRate("CAD", "USD"));
		assertEquals(new BigDecimal("6.1715"), fc.getExchangeRate("USD", "CNY"));
		assertEquals(new BigDecimal("1.2315"), fc.getExchangeRate("EUR", "USD"));
		assertEquals(new BigDecimal("1.5683"), fc.getExchangeRate("GBP", "USD"));
		assertEquals(new BigDecimal("0.7750"), fc.getExchangeRate("NZD", "USD"));
		assertEquals(new BigDecimal("119.95"), fc.getExchangeRate("USD", "JPY"));
		assertEquals(new BigDecimal("27.6028"), fc.getExchangeRate("EUR","CZK"));
		assertEquals(new BigDecimal("7.4405"), fc.getExchangeRate("EUR", "DKK"));
		assertEquals(new BigDecimal("8.6651"), fc.getExchangeRate("EUR", "NOK"));
	}
	
}
